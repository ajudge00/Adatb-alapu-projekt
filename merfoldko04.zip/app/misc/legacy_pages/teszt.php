<?php
echo password_hash('jelszo', PASSWORD_DEFAULT);