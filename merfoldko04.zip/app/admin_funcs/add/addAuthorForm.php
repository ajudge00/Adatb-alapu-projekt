<div class="container mt-5 mb-5">
    <h3>Szerző felvétele</h3>
    <form action="admin_funcs/add/addAuthor.php" method="post">
        <div class="form-group">
            <label for="name_input">Név</label>
            <input type="text" class="form-control" name="name" id="name_input">
        </div>

        <button type="submit" class="btn btn-success">Hozzáadás</button>
    </form>
</div>
